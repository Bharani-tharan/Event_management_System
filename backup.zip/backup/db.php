<?php

$con = mysqli_connect("localhost:3306", "root", "", "mini");

if(!$con){
    die("connection error");
}
?>